<?php

declare(strict_types=1);

namespace phpDocumentor\Reflection\PseudoTypes;

final class ListShapeItem extends ArrayShapeItem
{
}
