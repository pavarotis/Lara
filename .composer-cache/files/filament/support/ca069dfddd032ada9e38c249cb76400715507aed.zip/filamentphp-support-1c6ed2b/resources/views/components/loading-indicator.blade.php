{{ \Filament\Support\generate_loading_indicator_html($attributes) }}
