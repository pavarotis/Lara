<?php

return [

    'messages' => [
        'copied' => 'Đã sao chép',
    ],

];
