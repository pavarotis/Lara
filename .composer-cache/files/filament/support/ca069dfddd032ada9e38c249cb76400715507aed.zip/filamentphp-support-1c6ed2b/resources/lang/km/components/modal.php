<?php

return [

    'actions' => [

        'close' => [
            'label' => 'បិទ',
        ],

    ],

];
