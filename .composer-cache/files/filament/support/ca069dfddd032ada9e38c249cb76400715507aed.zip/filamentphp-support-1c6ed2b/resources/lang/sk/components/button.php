<?php

return [

    'messages' => [
        'uploading_file' => 'Nahrávam súbor...',
    ],

];
