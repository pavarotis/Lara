<?php

return [

    'actions' => [

        'close' => [
            'label' => 'बन्द गर्नुहोस्',
        ],

    ],

];
