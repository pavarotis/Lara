<?php

return [

    'actions' => [

        'close' => [
            'label' => 'Закрыть',
        ],

    ],

];
