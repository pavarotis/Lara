<?php

namespace Filament\Support\Commands\Exceptions;

use Exception;

class FailureCommandOutput extends Exception {}
