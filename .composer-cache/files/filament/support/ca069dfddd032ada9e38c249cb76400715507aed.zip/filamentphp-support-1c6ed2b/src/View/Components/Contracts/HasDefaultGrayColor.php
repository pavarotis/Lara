<?php

namespace Filament\Support\View\Components\Contracts;

interface HasDefaultGrayColor {}
