<?php

namespace Filament\Support\Enums;

enum GridDirection: string
{
    case Row = 'row';

    case Column = 'column';
}
