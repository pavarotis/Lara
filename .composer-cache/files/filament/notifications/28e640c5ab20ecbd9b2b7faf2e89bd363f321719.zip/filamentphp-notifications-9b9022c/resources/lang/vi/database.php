<?php

return [

    'modal' => [

        'heading' => 'Thông báo',

        'actions' => [

            'clear' => [
                'label' => 'Xóa',
            ],

            'mark_all_as_read' => [
                'label' => 'Đánh dấu là đã đọc tất cả',
            ],

        ],

        'empty' => [
            'heading' => 'Không có thông báo',
            'description' => 'Vui lòng kiểm tra lại sau.',
        ],

    ],

];
