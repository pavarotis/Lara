<?php

return [

    'single' => [

        'label' => 'Atkartoti',

        'modal' => [

            'heading' => 'Atkartoti :label',

            'actions' => [

                'replicate' => [
                    'label' => 'Atkartoti',
                ],

            ],

        ],

        'notifications' => [

            'replicated' => [
                'title' => 'Atkartota',
            ],

        ],

    ],

];
