<?php

return [

    'confirmation' => '이 작업을 수행하시겠습니까?',

    'actions' => [

        'cancel' => [
            'label' => '취소',
        ],

        'confirm' => [
            'label' => '확인',
        ],

        'submit' => [
            'label' => '제출',
        ],

    ],

];
