<?php

return [

    'single' => [

        'label' => 'Dzēst',

        'modal' => [

            'heading' => 'Dzēst :label',

            'actions' => [

                'delete' => [
                    'label' => 'Dzēst',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'Dzēsts',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Dzēst izvēlētos',

        'modal' => [

            'heading' => 'Dzēst izvēlētos :label',

            'actions' => [

                'delete' => [
                    'label' => 'Dzēst',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'Dzēsts',
            ],

        ],

    ],

];
