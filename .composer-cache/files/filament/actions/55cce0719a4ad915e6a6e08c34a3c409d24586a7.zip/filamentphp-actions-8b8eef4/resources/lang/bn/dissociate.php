<?php

return [

    'single' => [

        'label' => 'পৃথক করুন',

        'modal' => [

            'heading' => ':label পৃথক করুন',

            'actions' => [

                'dissociate' => [
                    'label' => 'পৃথক করুন',
                ],

            ],

        ],

        'notifications' => [

            'dissociated' => [
                'title' => 'পৃথক করা হয়েছে',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'নির্বাচিত গুলো পৃথক করুন',

        'modal' => [

            'heading' => 'নির্বাচিত :label পৃথক করুন',

            'actions' => [

                'dissociate' => [
                    'label' => 'পৃথক করুন',
                ],

            ],

        ],

        'notifications' => [

            'dissociated' => [
                'title' => 'পৃথক করা হয়েছে',
            ],

        ],

    ],

];
