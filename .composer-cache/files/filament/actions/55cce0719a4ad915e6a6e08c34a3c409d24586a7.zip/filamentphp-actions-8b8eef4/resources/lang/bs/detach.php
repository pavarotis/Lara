<?php

return [

    'single' => [

        'label' => 'Odvojite',

        'modal' => [

            'heading' => 'Odvojite :label',

            'actions' => [

                'detach' => [
                    'label' => 'Odvojite',
                ],

            ],

        ],

        'notifications' => [

            'detached' => [
                'title' => 'Odvojeno',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Odvojite izabrani',

        'modal' => [

            'heading' => 'Odvojite izabrani :label',

            'actions' => [

                'detach' => [
                    'label' => 'Odvojite izabrani',
                ],

            ],

        ],

        'notifications' => [

            'detached' => [
                'title' => 'Odvojeno',
            ],

        ],

    ],

];
