<?php

return [

    'single' => [

        'label' => 'እይ',
        'modal' => [

            'heading' => ':labelን እይ',
            'actions' => [

                'close' => [

                    'label' => 'ዝጋ',
                ],
            ],
        ],
    ],
];
