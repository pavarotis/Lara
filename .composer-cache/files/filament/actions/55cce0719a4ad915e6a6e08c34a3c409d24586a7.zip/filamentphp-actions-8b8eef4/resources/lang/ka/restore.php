<?php

return [

    'single' => [

        'label' => 'აღდგენა',

        'modal' => [

            'heading' => 'აღადგენთ :label',

            'actions' => [

                'restore' => [
                    'label' => 'აღდგენა',
                ],

            ],

        ],

        'notifications' => [

            'restored' => [
                'title' => 'აღდგენილია',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'არჩეულიების აღდგენა',

        'modal' => [

            'heading' => 'არჩეულიების აღდგენა :label',

            'actions' => [

                'restore' => [
                    'label' => 'აღდგენა',
                ],

            ],

        ],

        'notifications' => [

            'restored' => [
                'title' => 'აღდგენილია',
            ],

        ],

    ],

];
