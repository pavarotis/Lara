<?php

return [

    'single' => [

        'label' => 'Redaguoti',

        'modal' => [

            'heading' => 'Redaguoti :label',

            'actions' => [

                'save' => [
                    'label' => 'Išsaugoti pakeitimus',
                ],

            ],

        ],

        'notifications' => [

            'saved' => [
                'title' => 'Išsaugota',
            ],

        ],

    ],

];
