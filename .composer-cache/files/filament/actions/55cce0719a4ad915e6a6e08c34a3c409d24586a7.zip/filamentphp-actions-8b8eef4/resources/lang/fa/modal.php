<?php

return [

    'confirmation' => 'آیا برای انجام این کار مطمئن هستید؟',

    'actions' => [

        'cancel' => [
            'label' => 'لغو',
        ],

        'confirm' => [
            'label' => 'تایید',
        ],

        'submit' => [
            'label' => 'ثبت',
        ],

    ],

];
