<?php

return [

    'single' => [

        'label' => 'მოშორება',

        'modal' => [

            'heading' => 'აშორებთ :label',

            'actions' => [

                'detach' => [
                    'label' => 'მოშორება',
                ],

            ],

        ],

        'notifications' => [

            'detached' => [
                'title' => 'მოშორებულია',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'არჩეულიების მოშორება',

        'modal' => [

            'heading' => 'არჩეულიების მოშორება :label',

            'actions' => [

                'detach' => [
                    'label' => 'მოშორება',
                ],

            ],

        ],

        'notifications' => [

            'detached' => [
                'title' => 'მოშორებულია',
            ],

        ],

    ],

];
