<?php

return [

    'single' => [

        'label' => 'Възстанови',

        'modal' => [

            'heading' => 'Възстанови :label',

            'actions' => [

                'restore' => [
                    'label' => 'Възстанови',
                ],

            ],

        ],

        'notifications' => [

            'restored' => [
                'title' => 'Възстановен',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Възстанови избраните',

        'modal' => [

            'heading' => 'Възстанови избраните :label',

            'actions' => [

                'restore' => [
                    'label' => 'Възстанови',
                ],

            ],

        ],

        'notifications' => [

            'restored' => [
                'title' => 'Възстановени',
            ],

        ],

    ],

];
