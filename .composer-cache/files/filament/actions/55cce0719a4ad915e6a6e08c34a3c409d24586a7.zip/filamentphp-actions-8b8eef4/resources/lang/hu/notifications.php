<?php

return [

    'throttled' => [
        'title' => 'Túl sok próbálkozás',
        'body' => 'Kérjük próbáld újra :seconds másodperc múlva.',
    ],

];
