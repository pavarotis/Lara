<?php

return [

    'single' => [

        'label' => 'সংযুক্ত করুন',

        'modal' => [

            'heading' => ':label সংযুক্ত করুন',

            'fields' => [

                'record_id' => [
                    'label' => 'রেকর্ড',
                ],

            ],

            'actions' => [

                'attach' => [
                    'label' => 'সংযুক্ত করুন',
                ],

                'attach_another' => [
                    'label' => 'সংযুক্ত এবং পুনরায় সংযুক্ত করুন',
                ],

            ],

        ],

        'notifications' => [

            'attached' => [
                'title' => 'সংযুক্ত করা হয়েছে',
            ],

        ],

    ],

];
