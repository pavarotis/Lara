<?php

return [

    'single' => [

        'label' => 'عرض',

        'modal' => [

            'heading' => 'عرض :label',

            'actions' => [

                'close' => [
                    'label' => 'إغلاق',
                ],

            ],

        ],

    ],

];
