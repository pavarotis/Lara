<?php

return [

    'single' => [

        'label' => 'Pievienot',

        'modal' => [

            'heading' => 'Pievienot :label',

            'fields' => [

                'record_id' => [
                    'label' => 'Ieraksts',
                ],

            ],

            'actions' => [

                'attach' => [
                    'label' => 'Pievienot',
                ],

                'attach_another' => [
                    'label' => 'Pievienot & pievienot citu',
                ],

            ],

        ],

        'notifications' => [

            'attached' => [
                'title' => 'Pievienots',
            ],

        ],

    ],

];
