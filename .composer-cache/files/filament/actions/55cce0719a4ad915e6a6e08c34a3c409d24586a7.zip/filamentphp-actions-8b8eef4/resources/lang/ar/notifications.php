<?php

return [

    'throttled' => [
        'title' => 'تم تجاوز الحد المسموح',
        'body' => 'يرجى المحاولة مرة أخرى بعد :seconds ثانية.',
    ],

];
