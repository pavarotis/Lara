<?php

return [

    'distinct' => [
        'must_be_selected' => 'کم از کم ایک :attribute فیلڈ منتخب کرنا ضروری ہے۔',
        'only_one_must_be_selected' => 'صرف ایک :attribute فیلڈ منتخب کی جا سکتی ہے۔',
    ],

];
