<?php

return [

    'distinct' => [
        'must_be_selected' => 'Minst ett :attribute fält måste väljas.',
        'only_one_must_be_selected' => 'Endast ett :attribute fält kan väljas.',
    ],

];
