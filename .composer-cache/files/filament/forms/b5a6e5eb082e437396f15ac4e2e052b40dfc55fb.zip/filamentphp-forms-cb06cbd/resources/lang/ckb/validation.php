<?php

return [

    'distinct' => [
        'must_be_selected' => 'دەبێت لانیکەم یەک :attribute هەڵبژێردرێت.',
        'only_one_must_be_selected' => 'دەبێت تەنها یەک :attribute هەڵبژێردرێت.',
    ],

];
