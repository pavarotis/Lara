<?php

return [

    'distinct' => [
        'must_be_selected' => 'အနည်းဆုံး :attribute တစ်ခု ရွေးချယ်ရန် လိုအပ်ပါသည်',
        'only_one_must_be_selected' => ':attribute တစ်ခုသာ ရွေးချယ်ရန် လိုအပ်ပါသည်',
    ],

];
