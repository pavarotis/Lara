<?php

return [

    'distinct' => [
        'must_be_selected' => 'በ:attribute መስክ ቢያንስ አንድ መመረጥ አለበት።',
        'only_one_must_be_selected' => 'በ:attribute መስክ አንድ ብቻ ነው መመረጥ አለበት።',
    ],
];
