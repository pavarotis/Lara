<?php

return [

    'distinct' => [
        'must_be_selected' => 'Bent vienas :attribute laukas turi būti pasirinktas.',
        'only_one_must_be_selected' => 'Tik vienas :attribute laukas gali būti pasirinktas.',
    ],

];
