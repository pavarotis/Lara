<?php

return [

    'wizard' => [

        'actions' => [

            'previous_step' => [
                'label' => 'Sebelumnya',
            ],

            'next_step' => [
                'label' => 'Selanjutnya',
            ],

        ],

    ],

];
