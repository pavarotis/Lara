<?php

return [

    'wizard' => [

        'actions' => [

            'previous_step' => [
                'label' => 'Quay lại',
            ],

            'next_step' => [
                'label' => 'Tiếp theo',
            ],

        ],

    ],

];
