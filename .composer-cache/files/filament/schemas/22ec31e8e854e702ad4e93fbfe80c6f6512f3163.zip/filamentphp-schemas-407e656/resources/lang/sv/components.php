<?php

return [

    'wizard' => [

        'actions' => [

            'previous_step' => [
                'label' => 'Föregående',
            ],

            'next_step' => [
                'label' => 'Nästa',
            ],

        ],

    ],

];
