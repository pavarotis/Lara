<?php

return [

    'wizard' => [

        'actions' => [

            'previous_step' => [
                'label' => 'უკან',
            ],

            'next_step' => [
                'label' => 'შემდეგი',
            ],

        ],

    ],

];
