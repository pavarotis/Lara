<?php

return [

    'wizard' => [

        'actions' => [

            'previous_step' => [
                'label' => 'Aurrekoa',
            ],

            'next_step' => [
                'label' => 'Hurrengoa',
            ],

        ],

    ],

];
