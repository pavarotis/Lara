<?php

return [

    'wizard' => [

        'actions' => [

            'previous_step' => [
                'label' => 'Precedente',
            ],

            'next_step' => [
                'label' => 'Successivo',
            ],

        ],

    ],

];
