<?php

return [

    'wizard' => [

        'actions' => [

            'previous_step' => [
                'label' => 'Edellinen',
            ],

            'next_step' => [
                'label' => 'Seuraava',
            ],

        ],

    ],

];
