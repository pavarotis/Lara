<?php

return [

    'wizard' => [

        'actions' => [

            'previous_step' => [
                'label' => '返回',
            ],

            'next_step' => [
                'label' => '繼續',
            ],

        ],

    ],

];
