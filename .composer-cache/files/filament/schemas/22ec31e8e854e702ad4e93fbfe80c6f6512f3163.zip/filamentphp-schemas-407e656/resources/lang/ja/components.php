<?php

return [

    'wizard' => [

        'actions' => [

            'previous_step' => [
                'label' => '前へ',
            ],

            'next_step' => [
                'label' => '次へ',
            ],

        ],

    ],

];
