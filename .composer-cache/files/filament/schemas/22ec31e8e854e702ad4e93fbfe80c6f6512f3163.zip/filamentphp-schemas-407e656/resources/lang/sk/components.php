<?php

return [

    'wizard' => [

        'actions' => [

            'previous_step' => [
                'label' => 'Spať',
            ],

            'next_step' => [
                'label' => 'Ďalej',
            ],

        ],

    ],

];
