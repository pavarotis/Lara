<?php

namespace Filament\Schemas\Components\Contracts;

interface CanConcealComponents
{
    public function canConcealComponents(): bool;
}
