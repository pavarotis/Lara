<?php

namespace Filament\Schemas\View;

class SchemaIconAlias
{
    const COMPONENTS_WIZARD_COMPLETED_STEP = 'schema::components.wizard.completed-step';
}
