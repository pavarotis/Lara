<?php

return [

    'entries' => [

        'text' => [

            'actions' => [
                'collapse_list' => 'Vis :count mindre',
                'expand_list' => 'Vis :count flere',
            ],

            'more_list_items' => 'og :count flere',

        ],

        'key_value' => [

            'columns' => [

                'key' => [
                    'label' => 'Nøgle',
                ],

                'value' => [
                    'label' => 'Værdi',
                ],

            ],

            'placeholder' => 'Ingen data',

        ],

    ],

];
