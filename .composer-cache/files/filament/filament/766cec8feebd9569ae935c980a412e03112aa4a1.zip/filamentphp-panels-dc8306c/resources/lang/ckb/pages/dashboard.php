<?php

return [

    'title' => 'داشبۆرد',

    'actions' => [

        'filter' => [

            'label' => 'پاڵاوتن',

            'modal' => [

                'heading' => 'پاڵاوتن',

                'actions' => [

                    'apply' => [

                        'label' => 'جێبەجێکردن',

                    ],

                ],

            ],

        ],

    ],

];
