<?php

return [

    'title' => ':label সম্পাদন',

    'breadcrumb' => 'সম্পাদন করুন',

    'form' => [

        'actions' => [

            'cancel' => [
                'label' => 'বাতিল',
            ],

            'save' => [
                'label' => 'সম্পাদন করুন',
            ],

        ],

    ],

    'content' => [

        'tab' => [
            'label' => 'সম্পাদন',
        ],

    ],

    'notifications' => [

        'saved' => [
            'title' => 'সম্পাদন করা হয়েছে',
        ],

    ],

];
