<?php

return [

    'title' => 'Hallitse :label :relationship',

];
