<?php

return [

    'notifications' => [

        'verified' => [
            'title' => 'E-mail cím megváltoztatva',
            'body' => 'Az e-mail címed sikeresen megváltozott erre: :email.',
        ],

    ],

];
