<?php

return [

    'notifications' => [

        'verified' => [
            'title' => 'Dirección de correo electrónico cambiada',
            'body' => 'Su dirección de correo electrónico ha sido cambiada con éxito a :email.',
        ],

    ],

];
