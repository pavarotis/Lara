<?php

return [

    'form' => [

        'actions' => [

            'save' => [
                'label' => 'پاشەکەوتکردنی گۆڕانکارییەکان',
            ],

        ],

    ],

    'notifications' => [

        'saved' => [
            'title' => 'پاشەکەوتکرا',
        ],

    ],

];
