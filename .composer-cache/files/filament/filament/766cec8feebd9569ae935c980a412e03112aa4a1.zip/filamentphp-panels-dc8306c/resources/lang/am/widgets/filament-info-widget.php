<?php

return [

    'actions' => [

        'open_documentation' => [
            'label' => 'ሰነድ(ዶክ)',
        ],

        'open_github' => [
            'label' => 'GitHub',
        ],

    ],

];
