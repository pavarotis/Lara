<?php

return [

    'actions' => [

        'Klicken Sie zum',

        'copy' => [
            'label' => 'Kopieren',
        ],

        'oder',

        'download' => [
            'label' => 'Herunterladen',
        ],

        'aller Codes auf einmal.',

    ],

    'messages' => [
        'copied' => 'Kopiert',
    ],

];
