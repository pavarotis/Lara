<?php

return [
    'subject' => 'Zde je Váš přihlašovací kód',

    'lines' => [
        'Váš přihlašovací kód je: :code',
        'Tento kód vyprší za minutu.|Tento kód vyprší za :minutes minúty.|Tento kód vyprší za :minutes minut.',
    ],
];
