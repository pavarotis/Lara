<?php

return [
    'title' => 'Chyba při načítání stránky',

    'body' => 'Při pokusu o načtení této stránky došlo k chybě. Zkuste to prosím později znovu.',

];
