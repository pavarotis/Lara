<?php

return [

    'notifications' => [

        'verified' => [
            'title' => 'آدرس ایمیل تغییر کرد',
            'body' => 'آدرس ایمیل شما با موفقیت به :email تغییر یافت.',
        ],

    ],

];
