<?php

return [

    'title' => 'زیادکردنی :label',

    'breadcrumb' => 'زیادکردن',

    'form' => [

        'actions' => [

            'cancel' => [
                'label' => 'پاشگەزبوونەوە',
            ],

            'create' => [
                'label' => 'زیادکردن',
            ],

            'create_another' => [
                'label' => 'زیادکردن و تۆمارێکی تر',
            ],

        ],

    ],

    'notifications' => [

        'created' => [
            'title' => 'زیادکرا',
        ],

    ],

];
