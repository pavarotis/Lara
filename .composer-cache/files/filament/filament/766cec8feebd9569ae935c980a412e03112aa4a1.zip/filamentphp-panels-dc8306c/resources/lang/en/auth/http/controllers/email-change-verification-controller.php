<?php

return [

    'notifications' => [

        'verified' => [
            'title' => 'Email address changed',
            'body' => 'Your email address has been successfully changed to :email.',
        ],

    ],

];
