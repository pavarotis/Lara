<?php

return [

    'title' => 'Napravi :label',

    'breadcrumb' => 'Napravi',

    'form' => [

        'actions' => [

            'cancel' => [
                'label' => 'Odustani',
            ],

            'create' => [
                'label' => 'Napravi',
            ],

            'create_another' => [
                'label' => 'Napravi i dodaj još jedan',
            ],

        ],

    ],

    'notifications' => [

        'created' => [
            'title' => 'Napravljeno',
        ],

    ],

];
