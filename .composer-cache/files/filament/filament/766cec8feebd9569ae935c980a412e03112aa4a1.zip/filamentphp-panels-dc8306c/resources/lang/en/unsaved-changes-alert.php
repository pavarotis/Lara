<?php

return [

    'body' => 'You have unsaved changes. Are you sure you want to leave this page?',

];
