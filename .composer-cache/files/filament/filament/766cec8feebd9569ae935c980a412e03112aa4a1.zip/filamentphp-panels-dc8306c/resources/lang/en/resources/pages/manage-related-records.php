<?php

return [

    'title' => 'Manage :label :relationship',

];
