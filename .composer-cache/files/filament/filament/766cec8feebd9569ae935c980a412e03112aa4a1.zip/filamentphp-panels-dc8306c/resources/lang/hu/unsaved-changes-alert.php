<?php

return [

    'body' => 'Még nem történt meg a módosítások rögzítése. Biztos, hogy el akarod hagyni ezt az oldalt?',

];
