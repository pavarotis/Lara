<?php

return [

    'subject' => 'Aquí está su código de inicio de sesión',

    'lines' => [
        'Su código de inicio de sesión es: :code',
        'Este código expirará en un minuto.|Este código expirará en :minutes minutos.',
    ],

];
