<?php

return [

    'notifications' => [

        'verified' => [
            'title' => 'تم تغيير عنوان البريد الإلكتروني',
            'body' => 'تم تغيير عنوان بريدك الإلكتروني بنجاح إلى :email.',
        ],

    ],

];
